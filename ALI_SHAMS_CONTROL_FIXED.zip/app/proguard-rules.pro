# Keep VPN service
-keep class ir.markazkar.app.MarkazVpnService { *; }
-keep class ir.markazkar.app.Prefs { *; }
