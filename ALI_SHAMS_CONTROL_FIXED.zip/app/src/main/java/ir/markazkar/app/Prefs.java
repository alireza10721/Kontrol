package ir.markazkar.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * ذخیره‌سازی تنظیمات برنامه (VPN، کامپیوترها، دوربین)
 */
public final class Prefs {

    private static final String NAME = "markazkar_prefs";

    // VPN
    public static final String KEY_VPN_SERVER = "vpn_server";
    public static final String KEY_VPN_PORT = "vpn_port";
    public static final String KEY_VPN_USERNAME = "vpn_username";
    public static final String KEY_VPN_PASSWORD = "vpn_password";
    public static final String KEY_VPN_PROTOCOL = "vpn_protocol"; // openvpn / wireguard / ikev2
    public static final String KEY_VPN_CONFIG = "vpn_config";     // متن کانفیگ کامل WireGuard
    public static final String KEY_WG_CLIENT_PRIVATE = "wg_client_private";
    public static final String KEY_WG_SERVER_PUBLIC = "wg_server_public";

    // Camera / NVR
    public static final String KEY_CAMERA_IP = "camera_ip";
    public static final String KEY_CAMERA_PORT = "camera_port";
    public static final String KEY_CAMERA_USER = "camera_user";
    public static final String KEY_CAMERA_PASS = "camera_pass";

    // PCs
    public static final String KEY_PC_LIST = "pc_list_json";

    private final SharedPreferences sp;

    public Prefs(Context ctx) {
        sp = ctx.getApplicationContext().getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public String get(String key, String def) {
        return sp.getString(key, def);
    }

    public void put(String key, String value) {
        sp.edit().putString(key, value == null ? "" : value).apply();
    }

    // ---------- Defaults ----------
    public String getVpnServer() {
        return get(KEY_VPN_SERVER, "185.158.172.150");
    }

    public String getVpnPort() {
        return get(KEY_VPN_PORT, "51820");
    }

    public String getVpnUsername() {
        return get(KEY_VPN_USERNAME, "");
    }

    public String getVpnPassword() {
        return get(KEY_VPN_PASSWORD, "");
    }

    public String getVpnProtocol() {
        return get(KEY_VPN_PROTOCOL, "wireguard");
    }

    public String getVpnConfig() { return get(KEY_VPN_CONFIG, ""); }
    public String getWgClientPrivate() { return get(KEY_WG_CLIENT_PRIVATE, ""); }
    public String getWgServerPublic() { return get(KEY_WG_SERVER_PUBLIC, ""); }

    public String getCameraIp() {
        return get(KEY_CAMERA_IP, "192.168.10.18");
    }

    public String getCameraPort() {
        return get(KEY_CAMERA_PORT, "80");
    }

    public String getCameraUser() {
        return get(KEY_CAMERA_USER, "admin");
    }

    public String getCameraPass() {
        return get(KEY_CAMERA_PASS, "");
    }

    // ---------- PC List ----------
    public static class PcItem {
        public String name;
        public String ip;
        public String teamviewerId;

        public PcItem(String name, String ip, String teamviewerId) {
            this.name = name == null ? "" : name;
            this.ip = ip == null ? "" : ip;
            this.teamviewerId = teamviewerId == null ? "" : teamviewerId;
        }
    }

    public List<PcItem> getPcList() {
        String json = get(KEY_PC_LIST, "");
        List<PcItem> list = new ArrayList<>();
        if (json == null || json.isEmpty()) {
            // پیش‌فرض ۱۵ کامپیوتر
            for (int i = 1; i <= 15; i++) {
                list.add(new PcItem(
                        "کامپیوتر " + String.format("%02d", i),
                        "192.168.10." + (20 + i),
                        ""
                ));
            }
            return list;
        }
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                list.add(new PcItem(
                        o.optString("name", "کامپیوتر"),
                        o.optString("ip", ""),
                        o.optString("tv", "")
                ));
            }
        } catch (Exception e) {
            // fallback
            for (int i = 1; i <= 15; i++) {
                list.add(new PcItem("کامپیوتر " + String.format("%02d", i), "192.168.10." + (20 + i), ""));
            }
        }
        return list;
    }

    public void savePcList(List<PcItem> list) {
        try {
            JSONArray arr = new JSONArray();
            for (PcItem p : list) {
                JSONObject o = new JSONObject();
                o.put("name", p.name);
                o.put("ip", p.ip);
                o.put("tv", p.teamviewerId);
                arr.put(o);
            }
            put(KEY_PC_LIST, arr.toString());
        } catch (Exception ignored) {
        }
    }
}
