package ir.markazkar.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.wireguard.crypto.Key;
import com.wireguard.crypto.KeyPair;

import java.util.ArrayList;
import java.util.List;

public class SettingsActivity extends AppCompatActivity {

    private final int navy = Color.rgb(15, 28, 58);
    private final int teal = Color.rgb(45, 212, 191);
    private final int ink = Color.rgb(30, 41, 59);
    private final int muted = Color.rgb(100, 116, 139);
    private final int bg = Color.rgb(240, 244, 248);
    private final int cardBg = Color.WHITE;

    private Prefs prefs;
    private EditText etVpnServer, etVpnPort, etVpnUser, etVpnPass, etVpnConfig, etWgServerPublic;
    private TextView tvWgClientPublic;
    private EditText etCamIp, etCamPort, etCamUser, etCamPass;
    private LinearLayout pcContainer;
    private final List<PcRow> pcRows = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);

        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(32));
        scroll.addView(root);

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(4), dp(4), dp(4), dp(16));

        Button back = makeButton("← بازگشت", navy, Color.WHITE);
        back.setOnClickListener(v -> finish());
        header.addView(back, lp(dp(100), dp(40)));

        TextView title = makeText("تنظیمات", 22, navy, true);
        title.setPadding(dp(12), 0, 0, 0);
        header.addView(title);
        root.addView(header);

        // ===== VPN Section =====
        LinearLayout vpnCard = card(root, "تنظیمات WireGuard VPN");
        etVpnServer = field(vpnCard, "آدرس عمومی MikroTik", prefs.getVpnServer(), InputType.TYPE_CLASS_TEXT);
        etVpnPort = field(vpnCard, "پورت UDP WireGuard", prefs.getVpnPort(), InputType.TYPE_CLASS_NUMBER);
        etWgServerPublic = field(vpnCard, "کلید عمومی MikroTik (Server PublicKey)", prefs.getWgServerPublic(), InputType.TYPE_CLASS_TEXT);
        String clientPublic = ensureClientPublicKey();
        tvWgClientPublic = makeText("کلید عمومی این گوشی (برای ثبت Peer در MikroTik):\n" + clientPublic, 12, ink, false);
        tvWgClientPublic.setTextIsSelectable(true);
        vpnCard.addView(tvWgClientPublic);
        addGap(vpnCard, 6);
        Button copyKey = makeButton("کپی کلید عمومی گوشی", teal, navy);
        copyKey.setOnClickListener(v -> {
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("WireGuard public key", clientPublic));
            Toast.makeText(this, "کلید عمومی کپی شد", Toast.LENGTH_SHORT).show();
        });
        vpnCard.addView(copyKey, lp(-1, dp(42)));
        Button copyPeer = makeButton("کپی دستور ثبت گوشی در MikroTik", Color.rgb(15, 28, 58), Color.WHITE);
        copyPeer.setOnClickListener(v -> {
            String command = "/interface wireguard peers add interface=wg-markaz public-key=\"" + clientPublic
                    + "\" allowed-address=10.66.66.2/32 persistent-keepalive=25 comment=\"MarkazKar Android\"";
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("MikroTik Peer command", command));
            Toast.makeText(this, "دستور Peer کپی شد؛ در ترمینال MikroTik اجرا کنید", Toast.LENGTH_LONG).show();
        });
        vpnCard.addView(copyPeer, lp(-1, dp(42)));
        etVpnConfig = field(vpnCard, "کانفیگ کامل WireGuard (اختیاری؛ در صورت خالی‌بودن خودکار ساخته می‌شود)", 
                prefs.getVpnConfig(), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        etVpnConfig.setMinLines(3);
        etVpnConfig.setGravity(Gravity.TOP | Gravity.RIGHT);

        // ===== Camera Section =====
        LinearLayout camCard = card(root, "تنظیمات دوربین / NVR");
        etCamIp = field(camCard, "آی‌پی دستگاه ضبط (NVR)", prefs.getCameraIp(), InputType.TYPE_CLASS_TEXT);
        etCamPort = field(camCard, "پورت وب دستگاه ضبط", prefs.getCameraPort(), InputType.TYPE_CLASS_NUMBER);
        etCamUser = field(camCard, "نام کاربری", prefs.getCameraUser(), InputType.TYPE_CLASS_TEXT);
        etCamPass = field(camCard, "رمز عبور", prefs.getCameraPass(),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        // ===== PC List Section =====
        LinearLayout pcCard = card(root, "کامپیوترهای شبکه داخلی");
        pcCard.addView(makeText("نام، آی‌پی داخلی و شناسه TeamViewer را وارد کنید.", 13, muted, false));
        addGap(pcCard, 10);

        pcContainer = new LinearLayout(this);
        pcContainer.setOrientation(LinearLayout.VERTICAL);
        pcCard.addView(pcContainer);

        List<Prefs.PcItem> pcs = prefs.getPcList();
        for (Prefs.PcItem p : pcs) {
            addPcRow(p.name, p.ip, p.teamviewerId);
        }

        Button addPc = makeButton("+ افزودن کامپیوتر", teal, navy);
        addPc.setOnClickListener(v -> addPcRow("کامپیوتر جدید", "192.168.10.x", ""));
        pcCard.addView(addPc, lp(-1, dp(44)));
        addGap(pcCard, 6);

        // Save button
        addGap(root, 20);
        Button save = makeButton("ذخیره تنظیمات", teal, navy);
        save.setTextSize(16);
        save.setOnClickListener(v -> saveAll());
        root.addView(save, lp(-1, dp(52)));

        setContentView(scroll);
    }


    private String ensureClientPublicKey() {
        try {
            String privateKey = prefs.getWgClientPrivate();
            KeyPair pair;
            if (privateKey == null || privateKey.trim().isEmpty()) {
                pair = new KeyPair();
                prefs.put(Prefs.KEY_WG_CLIENT_PRIVATE, pair.getPrivateKey().toBase64());
            } else {
                pair = new KeyPair(Key.fromBase64(privateKey.trim()));
            }
            return pair.getPublicKey().toBase64();
        } catch (Exception e) {
            Toast.makeText(this, "ساخت کلید WireGuard ناموفق بود: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return "کلید ساخته نشد";
        }
    }

    private void addPcRow(String name, String ip, String tv) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable bg = round(Color.rgb(248, 250, 252), 12);
        bg.setStroke(dp(1), Color.rgb(226, 232, 240));
        row.setBackground(bg);

        LinearLayout.LayoutParams rowLp = lp(-1, -2);
        rowLp.bottomMargin = dp(10);
        pcContainer.addView(row, rowLp);

        EditText etName = fieldInline(row, "نام", name);
        EditText etIp = fieldInline(row, "آی‌پی داخلی", ip);
        EditText etTv = fieldInline(row, "شناسه TeamViewer", tv);

        Button del = makeButton("حذف", Color.rgb(239, 68, 68), Color.WHITE);
        del.setTextSize(12);
        del.setOnClickListener(v -> {
            pcContainer.removeView(row);
            pcRows.removeIf(r -> r.row == row);
        });
        row.addView(del, lp(-1, dp(36)));

        pcRows.add(new PcRow(row, etName, etIp, etTv));
    }

    private void saveAll() {
        prefs.put(Prefs.KEY_VPN_SERVER, etVpnServer.getText().toString().trim());
        prefs.put(Prefs.KEY_VPN_PORT, etVpnPort.getText().toString().trim());
        prefs.put(Prefs.KEY_WG_SERVER_PUBLIC, etWgServerPublic.getText().toString().trim());
        prefs.put(Prefs.KEY_VPN_CONFIG, etVpnConfig.getText().toString().trim());

        prefs.put(Prefs.KEY_CAMERA_IP, etCamIp.getText().toString().trim());
        prefs.put(Prefs.KEY_CAMERA_PORT, etCamPort.getText().toString().trim());
        prefs.put(Prefs.KEY_CAMERA_USER, etCamUser.getText().toString().trim());
        prefs.put(Prefs.KEY_CAMERA_PASS, etCamPass.getText().toString());

        List<Prefs.PcItem> list = new ArrayList<>();
        for (PcRow r : pcRows) {
            list.add(new Prefs.PcItem(
                    r.name.getText().toString().trim(),
                    r.ip.getText().toString().trim(),
                    r.tv.getText().toString().trim()
            ));
        }
        prefs.savePcList(list);

        Toast.makeText(this, "تنظیمات با موفقیت ذخیره شد", Toast.LENGTH_SHORT).show();
        setResult(RESULT_OK);
        finish();
    }

    // ---------- UI helpers ----------

    private LinearLayout card(LinearLayout parent, String title) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        box.setBackground(round(cardBg, 16));
        LinearLayout.LayoutParams p = lp(-1, -2);
        p.bottomMargin = dp(14);
        parent.addView(box, p);
        box.addView(makeText(title, 17, navy, true));
        addGap(box, 12);
        return box;
    }

    private EditText field(LinearLayout parent, String label, String value, int inputType) {
        parent.addView(makeText(label, 13, muted, false));
        addGap(parent, 4);
        EditText et = new EditText(this);
        et.setText(value);
        et.setTextSize(15);
        et.setTextColor(ink);
        et.setHintTextColor(Color.rgb(148, 163, 184));
        et.setInputType(inputType);
        et.setPadding(dp(12), dp(12), dp(12), dp(12));
        et.setBackground(round(Color.rgb(248, 250, 252), 10));
        et.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        et.setTextDirection(View.TEXT_DIRECTION_RTL);
        LinearLayout.LayoutParams p = lp(-1, -2);
        p.bottomMargin = dp(12);
        parent.addView(et, p);
        return et;
    }

    private EditText fieldInline(LinearLayout parent, String label, String value) {
        parent.addView(makeText(label, 12, muted, false));
        EditText et = new EditText(this);
        et.setText(value);
        et.setTextSize(14);
        et.setTextColor(ink);
        et.setPadding(dp(10), dp(8), dp(10), dp(8));
        et.setBackground(round(Color.WHITE, 8));
        et.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout.LayoutParams p = lp(-1, -2);
        p.bottomMargin = dp(8);
        parent.addView(et, p);
        return et;
    }

    private TextView makeText(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.RIGHT);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button makeButton(String s, int bgColor, int textColor) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(14);
        b.setTextColor(textColor);
        b.setAllCaps(false);
        b.setBackground(round(bgColor, 12));
        b.setStateListAnimator(null);
        return b;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private void addGap(LinearLayout l, int h) {
        View v = new View(this);
        l.addView(v, lp(1, dp(h)));
    }

    private int dp(int x) {
        return (int) (x * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static class PcRow {
        final LinearLayout row;
        final EditText name, ip, tv;

        PcRow(LinearLayout row, EditText name, EditText ip, EditText tv) {
            this.row = row;
            this.name = name;
            this.ip = ip;
            this.tv = tv;
        }
    }
}
