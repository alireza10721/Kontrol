package ir.markazkar.app;

import android.app.Activity;
import android.app.VpnService;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.security.KeyStore;
import java.util.*;
import java.util.concurrent.*;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends AppCompatActivity {
    private static final String STORE="ali_shams_control";
    private static final String[] TABS={"اتصال امن","ریموت کامپیوتر","سایت‌های من","اسکن IP","مدیریت NVR","تنظیمات"};
    private static final String[] ICONS={"◉","▣","◎","⌕","▤","⚙"};
    private int page=0; private LinearLayout root, content, nav; private TextView status;
    private Prefs prefs; private android.content.SharedPreferences data;
    private int bg, cardBg, text, muted, accent; private boolean dark;
    private final ExecutorService scanner=Executors.newFixedThreadPool(48);
    private volatile boolean scanning=false;
    private final BroadcastReceiver receiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){String s=i.getStringExtra(MarkazVpnService.EXTRA_STATE); if(s!=null) runOnUiThread(()->render());}};

    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=new Prefs(this); data=getSharedPreferences(STORE,MODE_PRIVATE); dark=data.getBoolean("dark",true); applyPalette(); getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL); IntentFilter f=new IntentFilter(MarkazVpnService.ACTION_STATUS); if(android.os.Build.VERSION.SDK_INT>=33) registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(receiver,f); render();}
    @Override protected void onDestroy(){try{unregisterReceiver(receiver);}catch(Exception ignored){} scanner.shutdownNow(); super.onDestroy();}
    private void applyPalette(){bg=dark?Color.rgb(12,18,34):Color.rgb(241,245,249);cardBg=dark?Color.rgb(25,35,56):Color.WHITE;text=dark?Color.WHITE:Color.rgb(25,35,55);muted=dark?Color.rgb(165,180,205):Color.rgb(100,116,139);accent=Color.rgb(45,212,191);getWindow().setStatusBarColor(dark?Color.rgb(9,15,29):Color.rgb(15,28,58));getWindow().setNavigationBarColor(dark?Color.rgb(9,15,29):Color.rgb(15,28,58));}
    private void render(){applyPalette(); root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(bg); ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);LinearLayout body=new LinearLayout(this);body.setOrientation(1);body.setPadding(dp(16),dp(14),dp(16),dp(18));scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(16),dp(18),dp(16),dp(18));header.setBackground(round(Color.rgb(15,28,58),22));TextView logo=txt("◈",32,accent,true);header.addView(logo);LinearLayout titleCol=new LinearLayout(this);titleCol.setOrientation(1);titleCol.setPadding(dp(12),0,0,0);titleCol.addView(txt("ALI SHAMS CONTROL",19,Color.WHITE,true));titleCol.addView(txt("مدیریت ارتباطات، شبکه و نظارت",12,Color.rgb(175,190,215),false));header.addView(titleCol,new LinearLayout.LayoutParams(0,-2,1));body.addView(header);gap(body,14);
        TextView heading=txt(TABS[page],21,text,true);body.addView(heading);TextView sub=txt("پنل یکپارچه مدیریت دستگاه‌ها و ارتباطات",12,muted,false);body.addView(sub);gap(body,12);
        LinearLayout grid=new LinearLayout(this);grid.setOrientation(1);for(int r=0;r<2;r++){LinearLayout line=new LinearLayout(this);for(int c=0;c<3;c++){final int idx=r*3+c;LinearLayout tile=new LinearLayout(this);tile.setOrientation(1);tile.setGravity(Gravity.CENTER);tile.setPadding(dp(4),dp(10),dp(4),dp(10));tile.setBackground(round(page==idx?Color.rgb(25,75,86):cardBg,15));TextView ic=txt(ICONS[idx],22,page==idx?accent:text,true);ic.setGravity(Gravity.CENTER);tile.addView(ic);TextView label=txt(TABS[idx],11,page==idx?accent:text,true);label.setGravity(Gravity.CENTER);tile.addView(label);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(70),1);p.setMargins(dp(3),dp(3),dp(3),dp(3));line.addView(tile,p);tile.setOnClickListener(v->{page=idx;render();});}grid.addView(line);}body.addView(grid);gap(body,14);
        content=new LinearLayout(this);content.setOrientation(1);body.addView(content);showPage();gap(body,14);TextView creator=txt("سازنده: alireza10721@gmail.com",11,muted,false);creator.setGravity(Gravity.CENTER);body.addView(creator);
        setContentView(root);
    }
    private void showPage(){switch(page){case 0:connectionPage();break;case 1:remotePage();break;case 2:websitesPage();break;case 3:scanPage();break;case 4:nvrPage();break;default:settingsPage();}}
    private void connectionPage(){cardTitle("اتصال امن WireGuard");boolean up=MarkazVpnService.isConnected();TextView s=txt(up?"● متصل به شبکه":"● اتصال برقرار نیست",16,up?accent:text,true);content.addView(s);gap(content,8);content.addView(txt("سرور: "+prefs.getVpnServer()+":"+prefs.getVpnPort(),13,muted,false));gap(content,14);Button b=button(up?"قطع اتصال":"اتصال WireGuard",up?Color.rgb(190,55,70):accent,up?Color.WHITE:Color.rgb(10,25,42));content.addView(b,lp(-1,52));b.setOnClickListener(v->toggleVpn());gap(content,10);Button cfg=button("تنظیم کلیدها و کانفیگ WireGuard",Color.rgb(45,65,100),Color.WHITE);content.addView(cfg,lp(-1,48));cfg.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));gap(content,10);content.addView(txt("کلید خصوصی گوشی و کلید عمومی سرور را در تنظیمات وارد کن. امکان استفاده از کانفیگ کامل WireGuard نیز وجود دارد.",12,muted,false));}
    private void remotePage(){
        cardTitle("ریموت کامپیوترها");
        Button addTv=button("＋ افزودن با TeamViewer",accent,Color.rgb(10,25,42));
        content.addView(addTv,lp(-1,46));
        addTv.setOnClickListener(v->editEntry("ثبت کامپیوتر TeamViewer",new String[]{"نام کامپیوتر","شناسه TeamViewer"},vals->{
            try{JSONArray a=array("pcs");JSONObject o=new JSONObject();o.put("name",vals[0]);o.put("tvId",vals[1]);o.put("type","teamviewer");a.put(o);saveArray("pcs",a);render();}
            catch(Exception e){toast("ذخیره کامپیوتر انجام نشد");}
        }));
        gap(content,8);
        Button addVnc=button("＋ افزودن با IP و VNC",Color.rgb(45,65,100),Color.WHITE);
        content.addView(addVnc,lp(-1,44));
        addVnc.setOnClickListener(v->editEntry("ثبت کامپیوتر با IP",new String[]{"نام کامپیوتر","آدرس IP","پورت VNC (معمولاً 5900)"},vals->{
            try{JSONArray a=array("pcs");JSONObject o=new JSONObject();o.put("name",vals[0]);o.put("host",vals[1]);o.put("port",vals[2].isEmpty()?"5900":vals[2]);o.put("type","vnc");a.put(o);saveArray("pcs",a);render();}
            catch(Exception e){toast("ذخیره کامپیوتر انجام نشد");}
        }));
        gap(content,10);
        JSONArray a=array("pcs");
        if(a.length()==0)content.addView(txt("هنوز کامپیوتری ثبت نشده است.",13,muted,false));
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;
            String name=o.optString("name","کامپیوتر");
            String id=o.optString("tvId","");
            String host=o.optString("host","");
            String port=o.optString("port","5900");
            if(!id.isEmpty()){
                item(name,"TeamViewer ID: "+id,"باز کردن TeamViewer",()->openTeamViewer(id),()->copy(id));
            }else if(!host.isEmpty()){
                item(name,host+":"+port,"اتصال با VNC",()->connectVnc(host,port),()->copy(host+":"+port));
            }
        }
        content.addView(txt("TeamViewer برای شروع اتصال باید روی گوشی نصب باشد. برنامه شناسه را کپی می‌کند و TeamViewer را باز می‌کند؛ رمز و تأیید اتصال را داخل خود TeamViewer وارد کن. برای VNC نیز باید VNC Server روی کامپیوتر و VNC Viewer روی گوشی نصب و تنظیم شده باشد.",11,muted,false));
    }
    private void websitesPage(){cardTitle("میانبر سایت‌های دلخواه");Button add=button("＋ ذخیره سایت جدید",accent,Color.rgb(10,25,42));content.addView(add,lp(-1,46));add.setOnClickListener(v->editEntry("سایت جدید",new String[]{"عنوان سایت","آدرس کامل (https://...)"},vals->{String u=normalizeUrl(vals[1]);if(!u.isEmpty()){JSONArray a=array("sites");JSONObject o=new JSONObject();try{o.put("name",vals[0]);o.put("url",u);a.put(o);saveArray("sites",a);render();}catch(Exception ignored){}}}));gap(content,10);JSONArray a=array("sites");if(a.length()==0)content.addView(txt("سایتی ذخیره نشده است.",13,muted,false));for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;String url=o.optString("url"),name=o.optString("name");item(name,url,"باز کردن",()->openUrl(url),()->copy(url));}}
    private void scanPage(){cardTitle("جست‌وجوی دستگاه‌های شبکه");EditText range=field("رنج شبکه (نمونه: 192.168.10.0/24)",data.getString("scan_range","192.168.10.0/24"));content.addView(range);gap(content,8);Button scan=button("شروع اسکن شبکه",accent,Color.rgb(10,25,42));content.addView(scan,lp(-1,48));TextView result=txt("فقط دستگاه‌هایی که روی پورت‌های متداول پاسخ دهند نمایش داده می‌شوند.",12,muted,false);content.addView(result);scan.setOnClickListener(v->{String r=range.getText().toString().trim();data.edit().putString("scan_range",r).apply();if(scanning)return;try{String[] p=r.split("/");if(p.length!=2||Integer.parseInt(p[1])!=24)throw new Exception();String[] oct=p[0].split("\\.");if(oct.length!=4)throw new Exception();String base=oct[0]+"."+oct[1]+"."+oct[2]+".";for(String q:oct){int n=Integer.parseInt(q);if(n<0||n>255)throw new Exception();}scanning=true;result.setText("در حال اسکن ۲۵۴ نشانی...");scan.setEnabled(false);scanHosts(base,result,scan);}catch(Exception e){result.setText("فرمت نامعتبر است. فعلاً فقط رنج /24 مانند 192.168.10.0/24 پشتیبانی می‌شود.");}});}
    private void scanHosts(String base,TextView result,Button scan){new Thread(()->{List<String> found=Collections.synchronizedList(new ArrayList<>());List<Future<?>> jobs=new ArrayList<>();for(int n=1;n<=254;n++){final String ip=base+n;jobs.add(scanner.submit(()->{int[] ports={80,443,554,3389,5900,22,8291,8080,37777};for(int port:ports){try(Socket s=new Socket()){s.connect(new InetSocketAddress(ip,port),230);found.add(ip+"  •  پورت "+port);return;}catch(Exception ignored){}}}));}for(Future<?> f:jobs){try{f.get(20,TimeUnit.SECONDS);}catch(Exception ignored){}}runOnUiThread(()->{scanning=false;scan.setEnabled(true);StringBuilder b=new StringBuilder("نتیجه اسکن: "+found.size()+" پاسخ");for(String h:found)b.append("\n").append(h);result.setText(b.toString());});}).start();}
    private void nvrPage(){
        cardTitle("دستگاه‌های NVR ذخیره‌شده");
        Button add=button("＋ افزودن NVR",accent,Color.rgb(10,25,42));
        content.addView(add,lp(-1,46));
        add.setOnClickListener(v->editEntry("ثبت دستگاه NVR",new String[]{"نام دستگاه","IP یا دامنه","پورت وب","نام کاربری","رمز عبور"},vals->{
            try{
                JSONArray a=array("nvrs");JSONObject o=new JSONObject();
                o.put("name",vals[0]);o.put("host",vals[1]);o.put("port",vals[2].isEmpty()?"80":vals[2]);
                o.put("user",vals[3]);o.put("pass",encrypt(vals[4]));a.put(o);saveArray("nvrs",a);render();
            }catch(Exception e){toast("ذخیره اطلاعات انجام نشد");}
        }));
        gap(content,10);
        JSONArray a=array("nvrs");
        if(a.length()==0)content.addView(txt("هنوز NVR ثبت نشده است.",13,muted,false));
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;
            final String host=o.optString("host"),port=o.optString("port","80"),name=o.optString("name");
            final String user=o.optString("user"),pass=o.optString("pass");
            item(name,host+":"+port+"  •  کاربر: "+user,"ورود به پنل",()->showNvrLoginDialog(host,port,user,pass),()->{
                String decoded=decrypt(pass);
                copy("نام کاربری: "+user+"\nرمز عبور: "+decoded);
                toast("نام کاربری و رمز کپی شد");
            });
        }
        content.addView(txt("با زدن «ورود به پنل»، پنجره ورود اطلاعات باز می‌شود. سپس نام کاربری و رمز کپی شده و صفحه وب دستگاه باز می‌شود. ورود خودکار در همه مدل‌های داهوا و هایک‌ویژن و سایر NVRها یکسان نیست و به نوع پنل دستگاه بستگی دارد.",11,muted,false));
    }
    private void showNvrLoginDialog(String host,String port,String savedUser,String encryptedPass){
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(18),dp(8),dp(18),dp(4));
        EditText userField=field("نام کاربری",savedUser);
        EditText passField=field("رمز عبور",decrypt(encryptedPass));
        passField.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(txt("آدرس دستگاه: "+host+":"+port,12,muted,false));
        box.addView(userField);box.addView(passField);
        box.addView(txt("با باز کردن پنل، اطلاعات ورود در کلیپ‌بورد قرار می‌گیرد تا در صفحه دستگاه جای‌گذاری کنی.",11,muted,false));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("ورود به دستگاه NVR").setView(box)
            .setPositiveButton("کپی اطلاعات و باز کردن پنل",null)
            .setNegativeButton("انصراف",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String u=userField.getText().toString().trim(),p=passField.getText().toString();
            if(u.isEmpty()){toast("نام کاربری را وارد کن");return;}
            copy("نام کاربری: "+u+"\nرمز عبور: "+p);
            String scheme="http";
            openUrl(scheme+"://"+host+(port.equals("80")?"":":"+port));
            toast("اطلاعات کپی شد؛ در صفحه دستگاه جای‌گذاری کن");
            dialog.dismiss();
        }));
        dialog.show();
    }
    private void settingsPage(){cardTitle("شخصی‌سازی برنامه");content.addView(txt("انتخاب پوسته",14,text,true));gap(content,8);Button theme=button(dark?"حالت فعلی: شب  •  تغییر به روشن":"حالت فعلی: روشن  •  تغییر به شب",Color.rgb(45,65,100),Color.WHITE);content.addView(theme,lp(-1,48));theme.setOnClickListener(v->{dark=!dark;data.edit().putBoolean("dark",dark).apply();render();});gap(content,10);Button wire=button("تنظیمات WireGuard و کلیدها",accent,Color.rgb(10,25,42));content.addView(wire,lp(-1,48));wire.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));gap(content,10);Button info=button("درباره برنامه و سازنده",Color.rgb(45,65,100),Color.WHITE);content.addView(info,lp(-1,46));info.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("ALI SHAMS CONTROL").setMessage("نسخه مدیریتی شبکه و دستگاه‌ها\nسازنده: alireza10721@gmail.com").setPositiveButton("باشه",null).show());gap(content,12);content.addView(txt("امنیت: رمز NVR رمزنگاری می‌شود. از ذخیره رمزهای حساس روی گوشی مشترک خودداری کنید. اسکن شبکه را فقط روی شبکه‌ای اجرا کنید که مالک آن هستید یا اجازه مدیریت آن را دارید.",12,muted,false));}

    private void toggleVpn(){if(MarkazVpnService.isConnected()){Intent i=new Intent(this,MarkazVpnService.class);i.setAction(MarkazVpnService.ACTION_DISCONNECT);startService(i);}else{Intent p=VpnService.prepare(this);if(p!=null)startActivityForResult(p,90);else startVpn();}}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==90){if(res==Activity.RESULT_OK)startVpn();else toast("مجوز VPN تأیید نشد");}}
    private void startVpn(){Intent i=new Intent(this,MarkazVpnService.class);i.setAction(MarkazVpnService.ACTION_CONNECT);ContextCompat.startForegroundService(this,i);toast("درخواست اتصال ارسال شد");}
    private void openTeamViewer(String id){
        if(id==null||id.trim().isEmpty()){toast("شناسه TeamViewer ثبت نشده است");return;}
        copy(id.trim());
        String pkg="com.teamviewer.teamviewer.market.mobile";
        Intent launch=getPackageManager().getLaunchIntentForPackage(pkg);
        if(launch!=null){
            try{startActivity(launch);toast("شناسه کپی شد؛ آن را در TeamViewer جای‌گذاری کن و رمز را همان‌جا وارد کن.");}
            catch(Exception e){toast("اجرای TeamViewer ناموفق بود");}
        }else{
            new AlertDialog.Builder(this).setTitle("TeamViewer نصب نیست")
                .setMessage("شناسه کپی شد. ابتدا TeamViewer Remote Control را نصب کن.")
                .setPositiveButton("رفتن به صفحه نصب",(d,w)->openUrl("https://play.google.com/store/apps/details?id="+pkg))
                .setNegativeButton("بستن",null).show();
        }
    }
    private void connectVnc(String host,String port){
        if(!MarkazVpnService.isConnected()&&!isLocalAddress(host)){
            new AlertDialog.Builder(this).setTitle("VPN متصل نیست")
                .setMessage("برای دسترسی به IP شبکه محل کار از بیرون، ابتدا WireGuard را وصل کن.")
                .setPositiveButton("اتصال VPN",(d,w)->toggleVpn())
                .setNegativeButton("ادامه",(d,w)->launchVnc(host,port)).show();
        }else launchVnc(host,port);
    }
    private void launchVnc(String host,String port){
        try{
            Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("vnc://"+host+":"+port));
            startActivity(i);
        }catch(Exception e){
            copy(host+":"+port);
            new AlertDialog.Builder(this).setTitle("VNC Viewer پیدا نشد")
                .setMessage("آدرس "+host+":"+port+" کپی شد. برای دیدن صفحه کامپیوتر، VNC Viewer را روی گوشی و VNC Server را روی کامپیوتر نصب کن.")
                .setPositiveButton("نصب VNC Viewer",(d,w)->openUrl("https://play.google.com/store/search?q=VNC%20Viewer&c=apps"))
                .setNegativeButton("بستن",null).show();
        }
    }
    private boolean isLocalAddress(String h){return h.startsWith("192.168.")||h.startsWith("10.")||h.startsWith("172.");}
    private void openUrl(String u){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){toast("امکان باز کردن آدرس نیست");}}
    private String normalizeUrl(String u){u=u.trim();if(u.isEmpty())return "";if(!u.startsWith("http://")&&!u.startsWith("https://"))u="https://"+u;return u;}
    private void editEntry(String title,String[] labels,java.util.function.Consumer<String[]> save){LinearLayout box=new LinearLayout(this);box.setPadding(dp(16),dp(8),dp(16),dp(4));box.setOrientation(1);EditText[] fields=new EditText[labels.length];for(int i=0;i<labels.length;i++){fields[i]=new EditText(this);fields[i].setSingleLine(true);fields[i].setTextColor(text);fields[i].setHintTextColor(muted);fields[i].setHint(labels[i]);if(labels[i].contains("رمز"))fields[i].setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);box.addView(fields[i]);}new AlertDialog.Builder(this).setTitle(title).setView(box).setPositiveButton("ذخیره",(d,w)->{String[] v=new String[fields.length];for(int i=0;i<v.length;i++)v[i]=fields[i].getText().toString().trim();if(v.length>1&&!v[1].isEmpty())save.accept(v);else toast("آدرس یا IP را وارد کن");}).setNegativeButton("انصراف",null).show();}
    private void item(String title,String detail,String action,Runnable click,Runnable copyAction){LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(13),dp(12),dp(13),dp(12));box.setBackground(round(cardBg,15));LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(8);content.addView(box,p);box.addView(txt(title,15,text,true));box.addView(txt(detail,11,muted,false));gap(box,8);LinearLayout row=new LinearLayout(this);Button open=button(action,accent,Color.rgb(10,25,42));row.addView(open,new LinearLayout.LayoutParams(0,dp(40),1));open.setOnClickListener(v->click.run());Button cp=button("کپی اطلاعات",Color.rgb(45,65,100),Color.WHITE);LinearLayout.LayoutParams cpP=new LinearLayout.LayoutParams(0,dp(40),1);cpP.setMargins(dp(6),0,0,0);row.addView(cp,cpP);cp.setOnClickListener(v->copyAction.run());box.addView(row);}
    private void cardTitle(String s){TextView t=txt(s,16,accent,true);content.addView(t);gap(content,10);}
    private JSONArray array(String k){try{return new JSONArray(data.getString(k,"[]"));}catch(Exception e){return new JSONArray();}}private void saveArray(String k,JSONArray a){data.edit().putString(k,a.toString()).apply();}
    private void copy(String s){android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("ALI SHAMS CONTROL",s));toast("کپی شد");}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private String encrypt(String plain)throws Exception{if(plain.isEmpty())return "";KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(!ks.containsAlias("ali_shams_nvr")){KeyGenerator kg=KeyGenerator.getInstance("AES","AndroidKeyStore");kg.init(new android.security.keystore.KeyGenParameterSpec.Builder("ali_shams_nvr",android.security.keystore.KeyProperties.PURPOSE_ENCRYPT|android.security.keystore.KeyProperties.PURPOSE_DECRYPT).setBlockModes("GCM").setEncryptionPaddings("NoPadding").build());kg.generateKey();}SecretKey key=(SecretKey)ks.getKey("ali_shams_nvr",null);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key);byte[] iv=c.getIV(),enc=c.doFinal(plain.getBytes("UTF-8"));byte[] all=new byte[iv.length+enc.length];System.arraycopy(iv,0,all,0,iv.length);System.arraycopy(enc,0,all,iv.length,enc.length);return android.util.Base64.encodeToString(all,android.util.Base64.NO_WRAP);}
    private String decrypt(String encoded){try{if(encoded.isEmpty())return "";byte[] all=android.util.Base64.decode(encoded,android.util.Base64.NO_WRAP),iv=Arrays.copyOfRange(all,0,12),enc=Arrays.copyOfRange(all,12,all.length);KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);SecretKey key=(SecretKey)ks.getKey("ali_shams_nvr",null);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,iv));return new String(c.doFinal(enc),"UTF-8");}catch(Exception e){return "(قابل بازیابی نیست)";}}
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.RIGHT);if(bold)t.setTypeface(Typeface.DEFAULT_BOLD);t.setLineSpacing(dp(2),1);return t;}
    private EditText field(String hint,String value){EditText e=new EditText(this);e.setSingleLine(true);e.setText(value);e.setHint(hint);e.setTextColor(text);e.setHintTextColor(muted);return e;}
    private Button button(String s,int b,int c){Button x=new Button(this);x.setText(s);x.setTextSize(13);x.setTextColor(c);x.setAllCaps(false);x.setBackground(round(b,13));x.setStateListAnimator(null);return x;}
    private GradientDrawable round(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private void gap(LinearLayout l,int h){View v=new View(this);l.addView(v,lp(1,dp(h)));}private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
}
