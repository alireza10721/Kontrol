package ir.markazkar.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Real WireGuard service. It never reports UP unless the WireGuard backend accepts the config. */
public class MarkazVpnService extends Service {
    public static final String ACTION_CONNECT = "ir.markazkar.app.VPN_CONNECT";
    public static final String ACTION_DISCONNECT = "ir.markazkar.app.VPN_DISCONNECT";
    public static final String ACTION_STATUS = "ir.markazkar.app.VPN_STATUS";
    public static final String EXTRA_STATE = "state";
    public static final String STATE_CONNECTING = "connecting";
    public static final String STATE_CONNECTED = "connected";
    public static final String STATE_DISCONNECTED = "disconnected";
    public static final String STATE_ERROR = "error";
    private static final String TAG = "MarkazWireGuard";
    private static final int NOTIF_ID = 1001;
    private static final String CHANNEL_ID = "markaz_wg_channel";
    private static volatile String currentState = STATE_DISCONNECTED;
    private static volatile String lastError = "";
    private static GoBackend backend;
    private static final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final Tunnel TUNNEL = new Tunnel() {
        @Override public String getName() { return "MarkazKar"; }
        @Override public void onStateChange(State state) { }
    };

    public static String getCurrentState() { return currentState; }
    public static String getLastError() { return lastError; }
    public static boolean isConnected() { return STATE_CONNECTED.equals(currentState); }

    @Override public void onCreate() { super.onCreate(); backend = new GoBackend(getApplicationContext()); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        if (ACTION_CONNECT.equals(intent.getAction())) connect();
        else if (ACTION_DISCONNECT.equals(intent.getAction())) disconnect();
        return START_NOT_STICKY;
    }

    private void connect() {
        if (STATE_CONNECTED.equals(currentState) || STATE_CONNECTING.equals(currentState)) return;
        lastError = "";
        broadcastState(STATE_CONNECTING, null);
        startForeground(NOTIF_ID, notification("در حال راه‌اندازی WireGuard..."));
        executor.execute(() -> {
            try {
                Prefs prefs = new Prefs(this);
                String raw = prefs.getVpnConfig().trim();
                if (raw.isEmpty()) {
                    String privateKey = prefs.getWgClientPrivate().trim();
                    String serverPublic = prefs.getWgServerPublic().trim();
                    if (privateKey.isEmpty() || serverPublic.isEmpty())
                        throw new IllegalArgumentException("کلید عمومی MikroTik را در تنظیمات وارد کنید؛ کلید گوشی به‌صورت خودکار ساخته شده است.");
                    raw = "[Interface]\nPrivateKey = " + privateKey
                            + "\nAddress = 10.66.66.2/32\nDNS = 192.168.10.1\nMTU = 1420\n\n[Peer]\nPublicKey = "
                            + serverPublic + "\nEndpoint = " + prefs.getVpnServer() + ":" + prefs.getVpnPort()
                            + "\nAllowedIPs = 192.168.10.0/24, 10.66.66.0/24\nPersistentKeepalive = 25\n";
                }
                Config config = Config.parse(new ByteArrayInputStream(raw.getBytes(StandardCharsets.UTF_8)));
                backend.setState(TUNNEL, Tunnel.State.UP, config);
                broadcastState(STATE_CONNECTED, null);
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (nm != null) nm.notify(NOTIF_ID, notification("WireGuard فعال است"));
            } catch (Exception e) {
                Log.e(TAG, "WireGuard connection failed", e);
                lastError = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                broadcastState(STATE_ERROR, lastError);
                stopForeground(true);
                stopSelf();
            }
        });
    }

    private void disconnect() {
        executor.execute(() -> {
            try {
                if (backend != null) backend.setState(TUNNEL, Tunnel.State.DOWN, null);
            } catch (Exception e) { Log.w(TAG, "Disconnect", e); }
            broadcastState(STATE_DISCONNECTED, null);
            stopForeground(true);
            stopSelf();
        });
    }

    private void broadcastState(String state, String error) {
        currentState = state;
        Intent i = new Intent(ACTION_STATUS).setPackage(getPackageName());
        i.putExtra(EXTRA_STATE, state);
        if (error != null) i.putExtra("error", error);
        sendBroadcast(i);
    }

    private Notification notification(String message) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "مرکز کار VPN", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_logo).setContentTitle("مرکز کار").setContentText(message)
                .setContentIntent(pi).setOngoing(STATE_CONNECTED.equals(currentState) || STATE_CONNECTING.equals(currentState))
                .setPriority(NotificationCompat.PRIORITY_LOW).build();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
