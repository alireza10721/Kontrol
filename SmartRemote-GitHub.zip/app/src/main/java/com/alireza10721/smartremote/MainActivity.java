package com.alireza10721.smartremote;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import android.hardware.ConsumerIrManager;

public class MainActivity extends Activity {
    int theme=0, temp=24;
    final int[][] palettes={
        {0xFF081A35,0xCC173D68,0xFF58C7FF,0xFFFFFFFF,0xFFB9E9FF},
        {0xFF071B2B,0xCC14506B,0xFF42D9E8,0xFFFFFFFF,0xFFB7F8FF},
        {0xFFF0F5FA,0xEEFfffff,0xFF3478C8,0xFF142B45,0xFFB9D9F5},
        {0xFF211B12,0xCC554126,0xFFFFC85A,0xFFFFF5DF,0xFFFFE4A6}
    };
    int bg, panel, accent, fg, glow;
    FrameLayout frame;
    LinearLayout page, body, drawer;
    boolean drawerOpen=false;

    @Override public void onCreate(Bundle b){super.onCreate(b); applyTheme(); home();}
    void applyTheme(){int[] p=palettes[theme];bg=p[0];panel=p[1];accent=p[2];fg=p[3];glow=p[4];getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);}

    GradientDrawable gradient(int c1,int c2,int radius){
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{c1,c2});
        d.setCornerRadius(radius); d.setStroke(1,0x667DDCFF); return d;
    }
    TextView label(String s,int size,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(fg);
        t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(14,10,14,10);
        if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
        return t;
    }
    LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void shell(String title){
        frame=new FrameLayout(this);
        page=vertical(); page.setPadding(16,10,16,12);
        page.setBackground(gradient(bg, darken(bg),0));
        LinearLayout top=horizontal();
        TextView menu=label("☰",28,true); menu.setGravity(Gravity.CENTER); menu.setBackground(gradient(0x553B9DDD,0x222B6A9A,30));
        top.addView(menu,new LinearLayout.LayoutParams(52,48));
        TextView brand=label("  SMART REMOTE",19,true); top.addView(brand,new LinearLayout.LayoutParams(0,48,1));
        TextView settings=label("⚙",25,true);settings.setGravity(Gravity.CENTER);settings.setOnClickListener(v->settings());
        top.addView(settings,new LinearLayout.LayoutParams(48,48)); page.addView(top);
        TextView heading=label(title,24,true);heading.setPadding(8,20,8,16);page.addView(heading);
        ScrollView scroll=new ScrollView(this); body=vertical(); body.setPadding(2,2,2,18);scroll.addView(body);
        page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout dock=horizontal();dock.setPadding(4,7,4,4);dock.setBackground(gradient(0xAA16446B,0xAA0A2443,26));
        dock.addView(dockButton("⌂\nخانه",()->home()),new LinearLayout.LayoutParams(0,58,1));
        dock.addView(dockButton("▣\nدستگاه‌ها",()->add()),new LinearLayout.LayoutParams(0,58,1));
        dock.addView(dockButton("⚙\nتنظیمات",()->settings()),new LinearLayout.LayoutParams(0,58,1));
        page.addView(dock);
        frame.addView(page);
        drawer=makeDrawer();
        FrameLayout.LayoutParams dp=new FrameLayout.LayoutParams((int)(getResources().getDisplayMetrics().widthPixels*.78),-1,Gravity.RIGHT);
        drawer.setTranslationX(getResources().getDisplayMetrics().widthPixels);
        frame.addView(drawer,dp);
        menu.setOnClickListener(v->toggleDrawer());
        frame.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN && drawerOpen && e.getX()<getResources().getDisplayMetrics().widthPixels*.2){toggleDrawer();}return true;});
        setContentView(frame);
    }
    int darken(int c){return Color.rgb((int)(Color.red(c)*.68),(int)(Color.green(c)*.68),(int)(Color.blue(c)*.68));}
    TextView dockButton(String s,Runnable r){TextView t=label(s,14,true);t.setGravity(Gravity.CENTER);t.setOnClickListener(v->r.run());return t;}
    LinearLayout makeDrawer(){
        LinearLayout d=vertical();d.setPadding(18,38,18,20);d.setBackground(gradient(0xF01A4770,0xF0091D37,0));
        TextView cap=label("◈  SMART REMOTE",20,true);d.addView(cap);
        TextView sub=label("منوی دسترسی سریع",13,false);d.addView(sub);
        drawerItem(d,"🏠   خانه",()->{toggleDrawer();home();});
        drawerItem(d,"📺   کنترل تلویزیون",()->{toggleDrawer();tv();});
        drawerItem(d,"❄   کنترل کولر گازی",()->{toggleDrawer();ac();});
        drawerItem(d,"＋   افزودن دستگاه",()->{toggleDrawer();add();});
        drawerItem(d,"🎨   تم‌های برنامه",()->{toggleDrawer();settings();});
        drawerItem(d,"⚙   تنظیمات",()->{toggleDrawer();settings();});
        View line=new View(this);line.setBackgroundColor(0x557CCFFF);d.addView(line,new LinearLayout.LayoutParams(-1,1));
        TextView maker=label("سازنده برنامه\nalireza10721@gmail.com",12,false);d.addView(maker);
        return d;
    }
    void drawerItem(LinearLayout d,String s,Runnable r){
        TextView t=label(s,16,true);t.setPadding(14,15,14,15);t.setBackground(gradient(0x334FC4FF,0x222B72A0,18));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,7,0,7);d.addView(t,lp);t.setOnClickListener(v->r.run());
    }
    void toggleDrawer(){drawerOpen=!drawerOpen;drawer.animate().translationX(drawerOpen?0:getResources().getDisplayMetrics().widthPixels).setDuration(230).start();}
    void glassCard(String icon,String title,String subtitle,Runnable action){
        LinearLayout box=vertical();box.setPadding(13,12,13,12);
        box.setBackground(gradient(0xCC28608A,0xCC102D50,22));
        box.setElevation(7);
        LinearLayout row=horizontal();
        TextView badge=label(icon,30,true);badge.setGravity(Gravity.CENTER);badge.setBackground(gradient(0x884DCBFF,0x443B76B5,18));
        row.addView(badge,new LinearLayout.LayoutParams(64,64));
        LinearLayout words=vertical();TextView a=label(title,19,true);TextView b=label(subtitle,12,false);
        words.addView(a);words.addView(b);row.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=label("‹",30,true);row.addView(arrow);box.addView(row);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,8,0,8);body.addView(box,lp);
        box.setOnClickListener(v->action.run());
    }
    void actionButton(String icon,String title,Runnable r){
        TextView b=label(icon+"   "+title,17,true);b.setGravity(Gravity.CENTER);
        b.setBackground(gradient(0xCC23547D,0xCC102A4A,18));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,58);lp.setMargins(0,6,0,6);body.addView(b,lp);b.setOnClickListener(v->r.run());
    }
    void home(){
        shell("خانه  /  کنترل هوشمند");
        glassCard("📺","تلویزیون","Hisense • SAM • LG • Samsung • Sony و سایر برندها",()->tv());
        glassCard("❄","کولر گازی","Hisense • SAM • LG • Gree • General و سایر برندها",()->ac());
        glassCard("＋","افزودن دستگاه جدید","انتخاب نوع دستگاه و برند",()->add());
        glassCard("☆","دستگاه‌های من","مدیریت ریموت‌های ذخیره‌شده",()->msg("هنوز دستگاهی ذخیره نشده است."));
        TextView hint=label("✦  ظاهر شیشه‌ای الهام‌گرفته از Windows 7 Aero",12,false);hint.setGravity(Gravity.CENTER);body.addView(hint);
    }
    void tv(){
        shell("تلویزیون  /  TV Remote");
        glassCard("📡","انتخاب برند","Hisense | SAM | LG | Samsung | Sony | Philips",()->add());
        actionButton("⏻","روشن / خاموش",()->notReady());
        actionButton("◀","منوی قبلی / برگشت",()->notReady());
        actionButton("⌂","خانه تلویزیون",()->notReady());
        actionButton("🔊","افزایش صدا",()->notReady());
        actionButton("🔉","کاهش صدا",()->notReady());
        actionButton("CH","کانال −     /     کانال +",()->notReady());
        actionButton("▣","ورودی تصویر  /  Source",()->notReady());irStatus();
    }
    void ac(){
        shell("کولر گازی  /  AC Remote");
        glassCard("❄","انتخاب برند کولر","Hisense | SAM | LG | Gree | General | O General",()->add());
        TextView degree=label("دمای تنظیم‌شده",15,false);degree.setGravity(Gravity.CENTER);body.addView(degree);
        TextView val=label(temp+"°",46,true);val.setGravity(Gravity.CENTER);body.addView(val);
        LinearLayout row=horizontal();
        TextView minus=dockButton("−",()->{temp=Math.max(16,temp-1);ac();});
        TextView plus=dockButton("+",()->{temp=Math.min(30,temp+1);ac();});
        minus.setTextSize(32);plus.setTextSize(32);minus.setBackground(gradient(0xCC24547A,0xCC102A4A,20));plus.setBackground(gradient(0xCC24547A,0xCC102A4A,20));
        row.addView(minus,new LinearLayout.LayoutParams(0,65,1));row.addView(plus,new LinearLayout.LayoutParams(0,65,1));body.addView(row);
        actionButton("❄","سرمایش",()->notReady());actionButton("☀","گرمایش",()->notReady());
        actionButton("💧","رطوبت‌گیر",()->notReady());actionButton("✣","سرعت فن / خودکار",()->notReady());
        actionButton("⏻","روشن / خاموش",()->notReady());irStatus();
    }
    void add(){
        shell("افزودن دستگاه");
        TextView typeLabel=label("نوع دستگاه",15,true);body.addView(typeLabel);
        Spinner type=new Spinner(this);type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"تلویزیون","کولر گازی"}));body.addView(type);
        body.addView(label("برند دستگاه",15,true));
        Spinner brand=new Spinner(this);brand.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Hisense","SAM","LG","Samsung","Sony","Philips","Panasonic","Gree","General","O General","سایر"}));body.addView(brand);
        actionButton("✓","ذخیره دستگاه",()->msg("فرم دستگاه آماده است. برای کنترل واقعی باید مدل دستگاه و روش اتصال پیکربندی شود."));
    }
    void settings(){
        shell("تنظیمات برنامه");
        glassCard("✉","سازنده برنامه","alireza10721@gmail.com",()->{});
        body.addView(label("🎨  انتخاب پوسته ظاهری",18,true));
        String[] names={"آبی شیشه‌ای Aero","فیروزه‌ای","روشن یخی","طلایی کلاسیک"};
        String[] icons={"💠","🌊","☀","✨"};
        for(int i=0;i<4;i++){final int n=i;actionButton(icons[i],names[i],()->{theme=n;applyTheme();settings();});}
        glassCard("ⓘ","درباره برنامه","Smart Remote  •  نسخه 1.1",()->msg("ریموت کنترل چندبرندی؛ نسخه اولیه رابط کاربری."));
        glassCard("ⓘ","راهنمای اتصال","IR و Wi‑Fi برای دستگاه‌های سازگار",()->msg("کنترل IR به فرستنده مادون‌قرمز و کد مناسب مدل نیاز دارد. کنترل Wi‑Fi نیز به پروتکل سازگار برند وابسته است."));
    }
    void irStatus(){
        ConsumerIrManager ir=(ConsumerIrManager)getSystemService(CONSUMER_IR_SERVICE);
        boolean has=ir!=null&&ir.hasIrEmitter();
        TextView t=label(has?"● فرستنده IR شناسایی شد؛ کدهای دستگاه لازم است.":"ⓘ این گوشی IR داخلی ندارد؛ برای کولر معمولی فرستنده IR جانبی لازم است.",12,false);
        t.setGravity(Gravity.CENTER);body.addView(t);
    }
    void notReady(){msg("این نسخه ظاهر و چیدمان کنترل را آماده کرده است. برای ارسال فرمان واقعی باید کدهای IR یا اتصال Wi‑Fi و پروتکل سازگار با مدل دستگاه اضافه شود.");}
    void msg(String s){new AlertDialog.Builder(this).setMessage(s).setPositiveButton("باشه",null).show();}
}
